function cargar_region(){
    var region = document.getElementById("regiones").value
    console.log(region)
    document.getElementById("region").html=region
}